# QADAM OFFICE Mini App

Telegram Mini App frontend only. Authentication is verified by the QADAM OFFICE Supabase Edge Function. No passwords or Telegram bot tokens are stored in this repository.

## Deploy to GitHub Pages

1. Create a **private** GitHub repository (recommended to manage source), and upload `index.html` and `.nojekyll` to its root.
2. Under **Settings > Pages**, enable GitHub Pages. GitHub Pages availability and public visibility depend on account/repository plan. If Pages is unavailable for the private repository, choose a public repository with only these nonsecret frontend files or use a different HTTPS host.
3. For source, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
4. Open the HTTPS `https://<username>.github.io/<repository>/` site and confirm it shows the QADAM OFFICE login form.
5. Update the Telegram `web_app` button URL in the `qadam-office-bot` function to that URL.

**Important:** GitHub Pages is public web hosting even when you use it to host a login form. Never commit passwords, bot tokens, service role keys, or private employee info. The login screen is not proof that an Owner account has been securely provisioned. Don't attempt to log in before the account is verified and activated.
